# KDC AgentPay — XRPL Connected Edition

Python FastAPI application with an interactive browser dashboard and XRP Ledger JSON-RPC integration via `xrpl-py`.

## Windows quick start
1. Install Python 3.11+ and ensure `py` works.
2. Run `setup_windows.bat` (requires internet to download dependencies).
3. Copy `.env.example` to `.env`. Set unique ADMIN_API_KEY and AGENT_API_KEY.
4. For live Testnet payments: set `XRPL_SEED` to a funded **Testnet-only** wallet seed and `XRPL_ENABLE_PAYMENTS=true`.
5. Run `start_windows.bat` and open http://127.0.0.1:8000

`GET /health` works without credentials. Use your API keys in the dashboard. `/docs` shows all endpoints.

## Safety and limitations
- Default network is **Testnet**, and sending is disabled until explicitly enabled.
- The `mainnet` option exists but is NOT production ready. Requires `XRPL_MAINNET_ACK=I_ACCEPT_REAL_FUNDS` and `XRPL_ENABLE_PAYMENTS=true`.
- Mainnet requires professional security review, external signer/HSM, rate limits, stronger multi-tenant authorization, destination tag handling, ledger reconciliation, exact integer-drop accounting, and durable job processing.
- This demo uses SQLite and one configured signing wallet. Do not expose the web server to the internet.
- Failed or ambiguous submissions are locked as `uncertain` to prevent blind retries. Manually reconcile before further action.
- Seeds are read from environment variables, not included in this archive. Do not commit `.env`.
- Dependencies are listed in requirements.txt and installed by setup_windows.bat. Packages are not bundled; setup requires network access.
- Live payment success requires an accessible XRPL server and a funded wallet. No transaction is initiated automatically.

Reference: https://xrpl.org/docs/tutorials/get-started/get-started-python

## Developer portal additions
Following https://xrpl.org/develop and the XRPL Python tutorial:
- GET /network/status checks the XRPL JSON-RPC node using ServerInfo.
- GET /transactions/{hash} checks transactions using Tx.
- GET /wallet reads the account using AccountInfo.
- POST /payments/{id}/execute submits authorized XRP payments.
- Run `python check_install.py` after dependency installation.

Live transactions require a funded wallet, correct seed and explicit opt-in.
