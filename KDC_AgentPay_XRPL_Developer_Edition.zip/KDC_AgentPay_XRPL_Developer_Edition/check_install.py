"""Offline smoke tests; requires installed dependencies."""
import os, tempfile
with tempfile.TemporaryDirectory() as d:
    os.environ["DATABASE_PATH"]=d+"/test.sqlite3"
    from fastapi.testclient import TestClient
    from app import app
    client=TestClient(app)
    assert client.get("/health").status_code==200
    assert client.get("/").status_code==200
    print("Local API smoke checks passed")
