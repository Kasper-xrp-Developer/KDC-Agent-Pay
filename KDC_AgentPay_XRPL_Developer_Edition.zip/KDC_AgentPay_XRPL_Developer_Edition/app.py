
import os, sqlite3, threading, secrets, re
from decimal import Decimal, InvalidOperation
from datetime import datetime, timezone
from uuid import uuid4
from contextlib import contextmanager
from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field
from dotenv import load_dotenv
load_dotenv()
from xrpl.clients import JsonRpcClient
from xrpl.models.requests import AccountInfo, ServerInfo, Tx
from xrpl.models.transactions import Payment
from xrpl.transaction import submit_and_wait
from xrpl.wallet import Wallet
from xrpl.core.addresscodec import is_valid_classic_address
from xrpl.utils import xrp_to_drops

NETWORKS = {"testnet":"https://s.altnet.rippletest.net:51234/",
            "mainnet":"https://s2.ripple.com:51234/"}
NETWORK=os.getenv("XRPL_NETWORK","testnet").lower()
if NETWORK not in NETWORKS: raise RuntimeError("Unsupported XRPL_NETWORK")
URL=NETWORKS[NETWORK]
ENABLED=os.getenv("XRPL_ENABLE_PAYMENTS","false").lower()=="true"
if NETWORK=="mainnet" and ENABLED and os.getenv("XRPL_MAINNET_ACK")!="I_ACCEPT_REAL_FUNDS":
    raise RuntimeError("Mainnet payments require XRPL_MAINNET_ACK=I_ACCEPT_REAL_FUNDS")
SEED=os.getenv("XRPL_SEED","")
ADMIN_KEY=os.getenv("ADMIN_API_KEY","")
AGENT_KEY=os.getenv("AGENT_API_KEY","")
DB=os.getenv("DATABASE_PATH","agentpay.sqlite3")
LOCK=threading.RLock()
app=FastAPI(title="KDC AgentPay — XRPL",version="1.0.0")
def now(): return datetime.now(timezone.utc).isoformat()
def auth_admin(x_api_key: str|None=Header(None)):
    if not ADMIN_KEY or not secrets.compare_digest(x_api_key or "",ADMIN_KEY):
        raise HTTPException(401,"Administrator API key required")
def auth_agent(x_api_key: str|None=Header(None)):
    if not AGENT_KEY or not secrets.compare_digest(x_api_key or "",AGENT_KEY):
        raise HTTPException(401,"Agent API key required")
def connect(): return sqlite3.connect(DB,timeout=30)
def initialize():
    with connect() as db:
        db.execute("CREATE TABLE IF NOT EXISTS agents (id TEXT PRIMARY KEY,budget TEXT NOT NULL,spent TEXT NOT NULL,frozen INTEGER NOT NULL)")
        db.execute("""CREATE TABLE IF NOT EXISTS payments (
          id TEXT PRIMARY KEY, agent TEXT NOT NULL, destination TEXT NOT NULL,
          amount TEXT NOT NULL, idem TEXT NOT NULL, status TEXT NOT NULL,
          approved_by TEXT, hash TEXT, result TEXT, created TEXT NOT NULL,
          UNIQUE(agent,idem))""")
        db.execute("INSERT OR IGNORE INTO agents VALUES (?,?,?,?)",("demo-agent",os.getenv("BUDGET_XRP","10"),"0",0))
initialize()
def rowpay(row):
    if not row: raise HTTPException(404,"Payment not found")
    keys=["payment_id","agent_id","destination","amount_xrp","idempotency_key","status","approved_by","tx_hash","ledger_result","created_at"]
    return dict(zip(keys,row),network=NETWORK)
def getpay(db,pid):
    return rowpay(db.execute("SELECT * FROM payments WHERE id=?",(pid,)).fetchone())
def amount_ok(raw):
    try: d=Decimal(raw)
    except (InvalidOperation,TypeError): raise HTTPException(422,"Invalid XRP amount")
    if not d.is_finite() or d<=0 or d.as_tuple().exponent < -6:
        raise HTTPException(422,"Amount must be positive, with at most six decimal places")
    return d
def wallet():
    if not SEED: raise HTTPException(503,"XRPL_SEED is not configured")
    return Wallet.from_seed(SEED)
class Prepare(BaseModel):
    agent_id: str="demo-agent"
    destination: str
    amount_xrp: str
    idempotency_key: str=Field(min_length=1,max_length=128)
class Approval(BaseModel):
    approved_by: str=Field(min_length=1)
@app.get("/health")
def health():
    return {"status":"ok","network":NETWORK,"rpc":URL,"payment_enabled":ENABLED,"wallet_configured":bool(SEED)}
@app.get("/network/status")
def network_status():
    try:
        response=JsonRpcClient(URL).request(ServerInfo())
        if not response.is_successful(): raise HTTPException(502,"XRPL server returned an error")
        info=response.result.get("info",{})
        return {"network":NETWORK,"rpc":URL,"server_state":info.get("server_state"),
                "validated_ledger":info.get("validated_ledger"),"connected":True}
    except HTTPException: raise
    except Exception as exc: raise HTTPException(502,f"XRPL network unavailable: {type(exc).__name__}")

@app.get("/transactions/{tx_hash}")
def transaction_lookup(tx_hash:str,_=Depends(auth_agent)):
    if not re.fullmatch(r"[A-Fa-f0-9]{64}",tx_hash):
        raise HTTPException(422,"Transaction hash must contain 64 hexadecimal characters")
    response=JsonRpcClient(URL).request(Tx(transaction=tx_hash))
    if not response.is_successful(): raise HTTPException(404,"Transaction not found")
    result=response.result
    return {"hash":tx_hash.upper(),"validated":result.get("validated",False),
            "result":result.get("meta",{}).get("TransactionResult"),
            "ledger_index":result.get("ledger_index"),"network":NETWORK}

@app.get("/wallet")
def wallet_info(_=Depends(auth_admin)):
    w=wallet()
    response=JsonRpcClient(URL).request(AccountInfo(account=w.classic_address,ledger_index="validated",strict=True))
    if not response.is_successful(): raise HTTPException(502,str(response.result))
    return {"address":w.classic_address,"balance_xrp":str(Decimal(response.result["account_data"]["Balance"])/1000000),"network":NETWORK,"validated":response.result.get("validated",False)}
@app.get("/agents/{agent_id}/budget")
def budget(agent_id:str,_=Depends(auth_agent)):
    with connect() as db:
        r=db.execute("SELECT budget,spent,frozen FROM agents WHERE id=?",(agent_id,)).fetchone()
        if not r: raise HTTPException(404,"Unknown agent")
        reserved=db.execute("SELECT amount FROM payments WHERE agent=? AND status IN ('pending_approval','approved','submitting','uncertain')",(agent_id,)).fetchall()
        remaining=Decimal(r[0])-Decimal(r[1])-sum((Decimal(x[0]) for x in reserved),Decimal(0))
        return {"agent_id":agent_id,"budget_xrp":r[0],"spent_xrp":r[1],"available_xrp":str(remaining),"frozen":bool(r[2])}
@app.post("/payments/prepare")
def prepare(req:Prepare,_=Depends(auth_agent)):
    amount=amount_ok(req.amount_xrp)
    if not is_valid_classic_address(req.destination): raise HTTPException(422,"Invalid XRPL classic destination address")
    with LOCK,connect() as db:
        old=db.execute("SELECT * FROM payments WHERE agent=? AND idem=?",(req.agent_id,req.idempotency_key)).fetchone()
        if old:
            p=rowpay(old)
            if p["destination"]!=req.destination or Decimal(p["amount_xrp"])!=amount:
                raise HTTPException(409,"Idempotency key reused for different payment")
            return p
        a=db.execute("SELECT budget,spent,frozen FROM agents WHERE id=?",(req.agent_id,)).fetchone()
        if not a: raise HTTPException(404,"Unknown agent")
        if a[2]: raise HTTPException(403,"Agent frozen")
        reserved=db.execute("SELECT amount FROM payments WHERE agent=? AND status IN ('pending_approval','approved','submitting','uncertain')",(req.agent_id,)).fetchall()
        if Decimal(a[1])+sum((Decimal(x[0]) for x in reserved),Decimal(0))+amount>Decimal(a[0]):
            raise HTTPException(403,"Budget exceeded")
        pid=str(uuid4())
        db.execute("INSERT INTO payments VALUES (?,?,?,?,?,?,?,?,?,?)",(pid,req.agent_id,req.destination,str(amount),req.idempotency_key,"pending_approval",None,None,None,now()))
        return getpay(db,pid)
@app.post("/payments/{payment_id}/approve")
def approve(payment_id:str,req:Approval,_=Depends(auth_admin)):
    with LOCK,connect() as db:
        p=getpay(db,payment_id)
        if p["status"]!="pending_approval": raise HTTPException(409,"Payment is not pending")
        frozen=db.execute("SELECT frozen FROM agents WHERE id=?",(p["agent_id"],)).fetchone()[0]
        if frozen: raise HTTPException(403,"Agent frozen")
        db.execute("UPDATE payments SET status='approved',approved_by=? WHERE id=?",(req.approved_by,payment_id))
        return getpay(db,payment_id)
@app.post("/payments/{payment_id}/execute")
def execute(payment_id:str,_=Depends(auth_admin)):
    if not ENABLED: raise HTTPException(403,"Payments disabled: set XRPL_ENABLE_PAYMENTS=true")
    w=wallet()
    with LOCK,connect() as db:
        p=getpay(db,payment_id)
        if p["status"]!="approved": raise HTTPException(409,"Payment not approved or already attempted")
        a=db.execute("SELECT budget,spent,frozen FROM agents WHERE id=?",(p["agent_id"],)).fetchone()
        if a[2]: raise HTTPException(403,"Agent frozen")
        if Decimal(a[1])+Decimal(p["amount_xrp"])>Decimal(a[0]): raise HTTPException(403,"Budget exceeded")
        # Commit before network call: never automatically resubmit ambiguous transactions.
        db.execute("UPDATE payments SET status='submitting' WHERE id=?",(payment_id,))
    try:
        client=JsonRpcClient(URL)
        tx=Payment(account=w.classic_address,destination=p["destination"],amount=xrp_to_drops(p["amount_xrp"]))
        response=submit_and_wait(tx,client,w)
        result=response.result
        txhash=result.get("hash") or result.get("tx_json",{}).get("hash")
        code=result.get("meta",{}).get("TransactionResult","unknown")
        validated=result.get("validated",False)
        with LOCK,connect() as db:
            if validated and code=="tesSUCCESS":
                db.execute("UPDATE payments SET status='validated',hash=?,result=? WHERE id=?",(txhash,code,payment_id))
                db.execute("UPDATE agents SET spent=? WHERE id=?",(str(Decimal(a[1])+Decimal(p["amount_xrp"])),p["agent_id"]))
            else:
                db.execute("UPDATE payments SET status='uncertain',hash=?,result=? WHERE id=?",(txhash,code,payment_id))
            return getpay(db,payment_id)
    except Exception as exc:
        with LOCK,connect() as db:
            db.execute("UPDATE payments SET status='uncertain',result=? WHERE id=?",(str(exc)[:300],payment_id))
        raise HTTPException(502,"Submission outcome uncertain; inspect ledger before retrying. Payment locked.")
@app.get("/payments/{payment_id}")
def payment(payment_id:str,_=Depends(auth_agent)):
    with connect() as db: return getpay(db,payment_id)
@app.get("/payments")
def list_payments(_=Depends(auth_admin)):
    with connect() as db: return [rowpay(r) for r in db.execute("SELECT * FROM payments ORDER BY created DESC LIMIT 100")]
@app.post("/agents/{agent_id}/freeze")
def freeze(agent_id:str,_=Depends(auth_admin)):
    with LOCK,connect() as db:
        cur=db.execute("UPDATE agents SET frozen=1 WHERE id=?",(agent_id,))
        if not cur.rowcount: raise HTTPException(404,"Unknown agent")
        return {"agent_id":agent_id,"frozen":True}
@app.get("/",response_class=HTMLResponse)
def dashboard():
    return """<!doctype html><html><head><meta charset="utf-8"><title>KDC AgentPay</title>
<style>body{background:#0b1010;color:#e9f8ee;font:16px system-ui;margin:0}main{max-width:850px;margin:40px auto;padding:24px}
h1{color:#62ff81}section{background:#17211c;border:1px solid #35513e;padding:20px;border-radius:14px;margin:15px 0}
input,button{padding:11px;border-radius:7px;margin:5px;border:1px solid #45664e;background:#0d1510;color:white}
button{background:#247f43;cursor:pointer}input{width:210px}pre{white-space:pre-wrap;word-break:break-word}</style></head>
<body><main><h1>KDC AgentPay · XRPL</h1><p>Live network queries and policy-gated payment execution</p>
<section><h3>Credentials (kept in this browser tab)</h3><input id="admin" type="password" placeholder="Admin API key">
<input id="agent" type="password" placeholder="Agent API key"></section>
<section><h3>Network</h3><button onclick="call('/health')">App status</button><button onclick="call('/network/status')">Live XRPL node</button>
<button onclick="call('/wallet','GET',null,true)">Wallet balance</button>
<button onclick="call('/agents/demo-agent/budget')">Agent budget</button></section>
<section><h3>Prepare payment</h3><input id="dest" placeholder="Destination r..."><input id="amount" placeholder="Amount XRP">
<input id="idem" placeholder="Unique request ID"><button onclick="prepare()">Prepare</button></section>
<section><h3>Approve / execute</h3><input id="pid" placeholder="Payment ID">
<button onclick="call('/payments/'+pid.value+'/approve','POST',{approved_by:'dashboard-admin'},true)">Approve</button>
<button onclick="call('/payments/'+pid.value+'/execute','POST',{},true)">Execute payment</button>
<button onclick="call('/payments/'+pid.value)">Check status</button></section>
<section><h3>Result</h3><pre id="out">Ready</pre></section><p><a href="/docs" style="color:#62ff81">API documentation</a></p></main>
<script>
async function call(path,method='GET',body=null,adminMode=false){
try{const headers={'X-API-Key':(adminMode?admin.value:agent.value)};
if(body!==null)headers['Content-Type']='application/json';
const r=await fetch(path,{method,headers,body:body===null?undefined:JSON.stringify(body)});
const data=await r.json();out.textContent=JSON.stringify(data,null,2);
if(data.payment_id)pid.value=data.payment_id;
}catch(e){out.textContent=String(e)}}
function prepare(){call('/payments/prepare','POST',{agent_id:'demo-agent',destination:dest.value,amount_xrp:amount.value,idempotency_key:idem.value||crypto.randomUUID()})}
</script></body></html>"""
