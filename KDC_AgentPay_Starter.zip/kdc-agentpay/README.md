# KDC AgentPay — XRPL AI Agent Payment Gateway

A safety-first starter API for AI agents to prepare XRP payments, enforce budgets, require approvals, and check validated settlement.

## Run

```bash
python -m pip install -r requirements.txt
uvicorn app:app --reload
```

Defaults to **dry-run mode**. No private keys are accepted or stored by this service. Real transaction signing must be implemented using a separate hardened signer (HSM/KMS or restricted signing service) after independent security review.

## Endpoints
- `GET /health`
- `GET /agents/{agent_id}/budget`
- `POST /payments/prepare`
- `POST /payments/{payment_id}/approve`
- `POST /payments/{payment_id}/execute` (dry-run only)
- `POST /agents/{agent_id}/freeze`

Example prepare:
```json
{"agent_id":"demo-agent","destination":"rEXAMPLE","amount_xrp":"0.5","idempotency_key":"order-1001"}
```

## Security notes
- Demo uses in-memory storage, not suitable for production or multiple workers.
- Authentication, RBAC, persistent transactional budgets, destination allowlists, sanctions checks, tamper-resistant audit logs, nonce/sequence management, XRPL network validation, and isolated signing are required for production.
- XRP amounts are handled as decimal strings. Never use floating-point for money.
- Execution does not transfer funds. It records a simulated payment only.
