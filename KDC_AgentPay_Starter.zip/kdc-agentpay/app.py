from decimal import Decimal, InvalidOperation
from threading import RLock
from uuid import uuid4
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="KDC AgentPay", version="0.1.0", description="Dry-run XRPL AI payment gateway")
lock = RLock()
payments = {}
idempotency = {}
agents = {"demo-agent": {"budget_xrp": Decimal("10"), "spent_xrp": Decimal("0"), "frozen": False}}

def timestamp():
    return datetime.now(timezone.utc).isoformat()

class Prepare(BaseModel):
    agent_id: str
    destination: str = Field(min_length=25, max_length=80)
    amount_xrp: str
    idempotency_key: str = Field(min_length=1, max_length=128)

class Approval(BaseModel):
    approved_by: str = Field(min_length=1)

@app.get("/health")
def health():
    return {"status": "ok", "mode": "dry-run", "network": "none"}

@app.get("/agents/{agent_id}/budget")
def budget(agent_id: str):
    with lock:
        a = agents.get(agent_id)
        if not a:
            raise HTTPException(404, "Unknown agent")
        return {"agent_id": agent_id, "budget_xrp": str(a["budget_xrp"]), "spent_xrp": str(a["spent_xrp"]), "remaining_xrp": str(a["budget_xrp"]-a["spent_xrp"]), "frozen": a["frozen"]}

@app.post("/payments/prepare")
def prepare(req: Prepare):
    try:
        amount = Decimal(req.amount_xrp)
    except InvalidOperation:
        raise HTTPException(400, "Invalid XRP amount")
    if not amount.is_finite() or amount <= 0 or amount.as_tuple().exponent < -6:
        raise HTTPException(400, "Amount must be positive with at most 6 decimal places")
    with lock:
        a = agents.get(req.agent_id)
        if not a:
            raise HTTPException(404, "Unknown agent")
        if a["frozen"]:
            raise HTTPException(403, "Agent frozen")
        key = (req.agent_id, req.idempotency_key)
        if key in idempotency:
            p = payments[idempotency[key]]
            if p["destination"] != req.destination or p["amount_xrp"] != str(amount):
                raise HTTPException(409, "Idempotency key reused with different payment")
            return p
        reserved = sum(Decimal(p["amount_xrp"]) for p in payments.values() if p["agent_id"] == req.agent_id and p["status"] in ("pending_approval", "approved"))
        if a["spent_xrp"] + reserved + amount > a["budget_xrp"]:
            raise HTTPException(403, "Budget exceeded")
        payment_id = str(uuid4())
        p = {"payment_id": payment_id, "agent_id": req.agent_id, "destination": req.destination, "amount_xrp": str(amount), "status": "pending_approval", "created_at": timestamp(), "mode": "dry-run"}
        payments[payment_id] = p
        idempotency[key] = payment_id
        return p

@app.post("/payments/{payment_id}/approve")
def approve(payment_id: str, req: Approval):
    with lock:
        p = payments.get(payment_id)
        if not p:
            raise HTTPException(404, "Payment not found")
        if p["status"] != "pending_approval":
            raise HTTPException(409, "Payment is not pending")
        if agents[p["agent_id"]]["frozen"]:
            raise HTTPException(403, "Agent frozen")
        p.update(status="approved", approved_by=req.approved_by, approved_at=timestamp())
        return p

@app.post("/payments/{payment_id}/execute")
def execute(payment_id: str):
    with lock:
        p = payments.get(payment_id)
        if not p:
            raise HTTPException(404, "Payment not found")
        if p["status"] != "approved":
            raise HTTPException(409, "Approval required")
        a = agents[p["agent_id"]]
        if a["frozen"]:
            raise HTTPException(403, "Agent frozen")
        amount = Decimal(p["amount_xrp"])
        if a["spent_xrp"] + amount > a["budget_xrp"]:
            raise HTTPException(403, "Budget exceeded")
        a["spent_xrp"] += amount
        p.update(status="simulated", simulated_at=timestamp(), tx_hash=None, ledger_validated=False)
        return p

@app.get("/payments/{payment_id}")
def get_payment(payment_id: str):
    with lock:
        if payment_id not in payments:
            raise HTTPException(404, "Payment not found")
        return payments[payment_id]

@app.post("/agents/{agent_id}/freeze")
def freeze(agent_id: str):
    with lock:
        if agent_id not in agents:
            raise HTTPException(404, "Unknown agent")
        agents[agent_id]["frozen"] = True
        return {"agent_id": agent_id, "frozen": True}
